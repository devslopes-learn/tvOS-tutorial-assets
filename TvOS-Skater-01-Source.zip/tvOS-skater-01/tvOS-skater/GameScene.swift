//
//  GameScene.swift
//  tvOS-skater
//
//  Created by Mark Price on 9/16/15.
//  Copyright (c) 2015 devslopes. All rights reserved.
//

import SpriteKit

class GameScene: SKScene {
    
    override func didMoveToView(view: SKView) {
        
        setupBackground()
    }
    
    func setupBackground() {
        //Set up background
        let bg = SKSpriteNode(imageNamed: "bg1")
        bg.position = CGPointMake(517, 400)
        bg.zPosition = 3
        self.addChild(bg)
        
        let bg2 = SKSpriteNode(imageNamed: "bg2")
        bg2.position = CGPointMake(517, 450)
        bg2.zPosition = 2
        self.addChild(bg2)
        
        let bg3 = SKSpriteNode(imageNamed: "bg3")
        bg3.position = CGPointMake(517, 500)
        bg3.zPosition = 1
        self.addChild(bg3)
    }

    override func update(currentTime: CFTimeInterval) {
        /* Called before each frame is rendered */
    }
}
